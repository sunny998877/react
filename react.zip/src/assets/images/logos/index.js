import logo from './logo.jpg';
import mainLogo from './main-logo.svg';

export const common = {
  logo,
  mainLogo
};
