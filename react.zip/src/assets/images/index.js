import { common } from './logos/index';

const images = {
  common
};

export default images;
