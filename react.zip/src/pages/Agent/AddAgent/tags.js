export const tags = [
  {
    name: 'SUNOUT',
    id: 0
  },
  {
    name: 'MONINB',
    id: 1
  },
  {
    name: 'MONOUT',
    id: 2
  },
  {
    name: 'TUEINB',
    id: 3
  },
  {
    name: 'WEDINB',
    id: 4
  },
  {
    name: 'WEDOUT',
    id: 5
  },
  {
    name: 'THUOUT',
    id: 6
  },
  {
    name: 'FRIOUT',
    id: 7
  },
  {
    name: 'SATINB',
    id: 8
  },
  {
    name: 'SATOUT',
    id: 9
  }
];
