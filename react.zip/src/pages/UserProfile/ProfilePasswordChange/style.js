import { makeStyles } from '@material-ui/styles';

export const useStyles = makeStyles({
  formContainer: {},
  btnWapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end'
  }
});
